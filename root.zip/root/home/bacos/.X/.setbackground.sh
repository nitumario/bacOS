#!/bin/sh
hsetroot  -fill /home/msmd/Images/wallpaper.jpg
